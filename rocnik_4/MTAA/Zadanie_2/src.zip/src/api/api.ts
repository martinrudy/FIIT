export const QUERY_KEYS = {
  recipes: "recipes",
  food: "food",
  foodTypes: "foodTypes",
  refrigerators: "refrigerators",
};
